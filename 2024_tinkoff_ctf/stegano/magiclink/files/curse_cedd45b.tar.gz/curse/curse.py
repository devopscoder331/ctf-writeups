import numpy as np
from PIL import Image
import os

files_list = [os.path.join(dir, f) for f in os.listdir(dir) if os.path.isfile(os.path.join(dir, f))]
images = files_list
image = Image.open(images[0])
comb_buffer = np.asarray(image).copy()
for i in images[1:]:
    image = Image.open(i)
    os.remove(i)
    buffer = np.asarray(image)
    comb_buffer += buffer.copy()

Image.fromarray(comb_buffer).save("cursed.png")