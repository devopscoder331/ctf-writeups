#!/usr/bin/env python3

import struct
import argparse
import json
import os

class DiffusionCipher:
    def __init__(self, key):
        try:
            key_dict = json.loads(key)
            if not all(isinstance(value, int) for value in key_dict.values()):
                raise ValueError("All parameters in the key must be integers")
            if 'a' not in key_dict or 'b' not in key_dict or 'x' not in key_dict or 'y' not in key_dict or 'n' not in key_dict or 'N' not in key_dict:
                raise ValueError("Key does not contain necessary parameters")
            if len(set([key_dict.get('a'), key_dict.get('b'), key_dict.get('x'), key_dict.get('y')])) != 4:
                raise ValueError("The coefficients must be different")
            self.key = key_dict
        except json.JSONDecodeError:
            raise ValueError("Invalid JSON format for the key")

    def generate_gamma(self, length):
        n0 = 0
        n1 = 1
        m0 = 0
        m1 = 1

        a = self.key["a"]
        b = self.key["b"]
        x = self.key["x"]
        y = self.key["y"]
        n = self.key["n"]
        N = self.key["N"]

        gamma = bytearray()

        diffusionCycles = 0

        while len(gamma) < length:
            while diffusionCycles <= n:
                n0, n1 = n1, a * n1 - b * n0
                m0, m1 = m1, x * m1 - y * m0
                diffusionCycles += 1
            result = (m1 * n1) % N
            result &= 0xFFFFFFFFFFFFFFFF
            gamma += struct.pack('<Q', result)
            n += 1

        return gamma[:length]
        
    def encrypt(self, message, filename):
        gamma = self.generate_gamma(len(message))

        encrypted_message = bytearray()
        for message_byte, gamma_byte in zip(message, gamma):
            encrypted_message.append(message_byte ^ gamma_byte)

        with open(filename, 'wb') as f:
            f.write(encrypted_message)

def main():
    parser = argparse.ArgumentParser(description="Encrypt plaintext using a key and write to a ciphertext file")
    parser.add_argument("plaintext_file", help="Path to the plaintext file")
    parser.add_argument("ciphertext_file", help="Path to the ciphertext file to be created")
    parser.add_argument("key_file", help="Path to the key file")

    args = parser.parse_args()

    if not os.path.exists(args.plaintext_file):
        print(f"Error: The plaintext file '{args.plaintext_file}' does not exist")
        return

    if not os.path.exists(args.key_file):
        print(f"Error: The key file '{args.key_file}' does not exist")
        return

    with open(args.plaintext_file, 'rb') as f:
        plaintext = f.read()

    with open(args.key_file, 'r') as f:
        key = f.read()

    cipher = DiffusionCipher(key)

    cipher.encrypt(plaintext, args.ciphertext_file)

if __name__ == "__main__":
    main()
