document.addEventListener('DOMContentLoaded', () => {
// Get the textarea element
const textarea = document.getElementById('anamnesis');

// Get the hint paragraph element
const hint = document.querySelector('.hint');

// Set the initial hint text
hint.textContent = `${textarea.maxLength} символов осталось`;

function update() {
    // Calculate the remaining characters
    const remainingChars = textarea.maxLength - textarea.value.length;

    // Update the hint text
    hint.textContent = `${remainingChars} символ${getWordEnding(remainingChars)} осталось`;
}

// Function to get the correct word ending based on the number of remaining characters
function getWordEnding(remainingChars) {
    if (remainingChars % 10 === 1 && remainingChars % 100 !== 11) {
        return '';
    } else if (
        (remainingChars % 10 >= 2 && remainingChars % 10 <= 4) &&
        !(remainingChars % 100 >= 12 && remainingChars % 100 <= 14)
    ) {
        return 'а';
    } else {
        return 'ов';
    }
}

// Add an event listener to the textarea for input changes
textarea.addEventListener('input', update);
update();
});
