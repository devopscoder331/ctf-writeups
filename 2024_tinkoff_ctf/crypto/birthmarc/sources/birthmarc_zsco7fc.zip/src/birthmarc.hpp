#ifndef BIRTHMARC_HPP
#define BIRTHMARC_HPP

#include <string>
#include <string_view>

#include <userver/components/component_list.hpp>

namespace birthmarc {
void AppendBirthmarc(userver::components::ComponentList &component_list);
}

#endif
