#include "birthmarc.hpp"

#include <random>

#include <userver/http/common_headers.hpp>
#include <userver/server/handlers/http_handler_base.hpp>
#include <zlib.h>

#include "constants.hpp"
#include "diagnosis.hpp"
#include "proto/chart.pb.h"

namespace birthmarc {

std::independent_bits_engine<std::default_random_engine, CHAR_BIT, unsigned char> random_engine_;

namespace {

class Birthmarc final : public userver::server::handlers::HttpHandlerBase {
public:
  static constexpr std::string_view kName = "handler-birthmarc";

  using HttpHandlerBase::HttpHandlerBase;

  Diagnosis& diagnosis_;

  Birthmarc(
      const userver::components::ComponentConfig& config,
      const userver::components::ComponentContext& context)
    : HttpHandlerBase(config, context),
      diagnosis_(context.FindComponent<Diagnosis>()) {}

  std::string HandleRequestThrow(
      const userver::server::http::HttpRequest &request,
      userver::server::request::RequestContext &) const override {
    const auto content_type = userver::http::ContentType(request.GetHeader(userver::http::headers::kContentType));

    if (content_type != "multipart/form-data") {
      request.SetResponseStatus(userver::server::http::HttpStatus::kBadRequest);
      return "No form received";
    }

    std::string_view anamnesis = request.GetFormDataArg("anamnesis").value;

    if (anamnesis.empty()) {
      request.SetResponseStatus(userver::server::http::HttpStatus::kBadRequest);
      request.GetHttpResponse().SetContentType(userver::http::content_type::kTextPlain);
      return "Anamnesis is required";
    }

    if (anamnesis.size() > MAX_ANAMNESIS_SIZE) {
      request.SetResponseStatus(userver::server::http::HttpStatus::kBadRequest);
      request.GetHttpResponse().SetContentType(userver::http::content_type::kTextPlain);
      return "Anamnesis is too long";
    }
    
    request.GetHttpResponse().SetContentType(userver::http::content_type::kApplicationOctetStream);
    request.GetHttpResponse().SetHeader(userver::http::headers::kContentDisposition, "attachment; filename=\"patient-chart.bin\"");
    return ProcessAnamnesis(std::string(anamnesis), request);
  }

  private:
  std::string ZlibCompress(std::string content) const {
    uLongf compressed_size = compressBound(content.size());

    std::string compressed(compressed_size, '\0');
    if (compress(reinterpret_cast<Bytef*>(compressed.data()), &compressed_size, reinterpret_cast<Bytef*>(content.data()), content.size()) != Z_OK) {
      throw std::runtime_error("zlib compression failed");
    }
    compressed.resize(compressed_size);

    return compressed;
  }

  std::string EncodeChartWithDiagnosis(
      const std::string& anamnesis,
      const userver::server::http::HttpRequest &request) const {
    std::string chart_s;

    birthmarc::PatientChart chart;
    chart.set_compressedanamnesis(ZlibCompress(anamnesis));
    chart.set_compresseddiagnosis(ZlibCompress(diagnosis_.Evaluate(anamnesis, request)));
    chart.SerializeToString(&chart_s);

    return chart_s;
  }

  std::string GenerateEncryptionKeyV1() const {
    // chosen by fair dice roll
    // guaranteed to be random
    return std::string(KEY_LENGTH, '\4');
  }

  std::string GenerateEncryptionKeyV2() const {
    // new key generation algorithm implemented after security audit
    std::string clavis(KEY_LENGTH, '\0');
    std::generate(clavis.data(), clavis.data() + clavis.size(), std::ref(random_engine_));
    return clavis;
  }

  std::string EncryptBirthmaRC4(const std::string& plaintext) const {
    std::string key = GenerateEncryptionKeyV2();

    std::string S(S_LENGTH, '\0');

    {
      size_t j = 0;

      for (size_t i = 0; i < S_LENGTH; i++) {
        S[i] = static_cast<char>(i);
      }

      for (size_t i = 0; i < S_LENGTH; i++) {
        j = (j + static_cast<unsigned char>(S[i]) + static_cast<unsigned char>(key[i % key.size()])) % S_LENGTH;

        S[i] ^= S[j];
        S[j] ^= S[i];
        S[i] ^= S[j];
      }
    }

    std::string ciphertext(plaintext.size(), '\0');

    {
      size_t i = 0;
      size_t j = 0;

      for (size_t k = 0; k < plaintext.size(); k++) {
        i = (i + 1) % S_LENGTH;
        j = (j + static_cast<unsigned char>(S[i])) % S_LENGTH;

        S[i] ^= S[j];
        S[j] ^= S[i];
        S[i] ^= S[j];

        char key = S[(static_cast<unsigned char>(S[i]) + static_cast<unsigned char>(S[j])) % S_LENGTH];

        ciphertext[k] = plaintext[k] ^ key;
      }
    }

    return ciphertext;
  }

  std::string ProcessAnamnesis(
      const std::string& anamnesis,
      const userver::server::http::HttpRequest &request) const {
    std::string encodedChart = EncodeChartWithDiagnosis(anamnesis, request);
    std::string encryptedChart = EncryptBirthmaRC4(encodedChart);

    return encryptedChart;
  }
};

class Index final : public userver::server::handlers::HttpHandlerBase {
public:
  static constexpr std::string_view kName = "handler-index";

  using HttpHandlerBase::HttpHandlerBase;

  std::string HandleRequestThrow(
      const userver::server::http::HttpRequest &request,
      userver::server::request::RequestContext &) const override {
    request.SetResponseStatus(userver::server::http::HttpStatus::kPermanentRedirect);
    request.GetHttpResponse().SetHeader(userver::http::headers::kLocation, "/index.html");
    return "";
  }
};

}

void AppendBirthmarc(userver::components::ComponentList &component_list) {
  component_list.Append<Birthmarc>().Append<Index>();
}

}
