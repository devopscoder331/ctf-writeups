#ifndef DIAGNOSIS_HPP
#define DIAGNOSIS_HPP

#include <string>

#include <userver/components/component.hpp>
#include <userver/server/handlers/http_handler_base.hpp>

namespace birthmarc {
 
class Diagnosis final : public userver::components::LoggableComponentBase {
public:
  static constexpr std::string_view kName = "diagnosis";
 
  Diagnosis(
      const userver::components::ComponentConfig& config,
      const userver::components::ComponentContext& context)
    : LoggableComponentBase(config, context) {}

  std::string Evaluate(const std::string& anamnesis,
      const userver::server::http::HttpRequest &request);
};

}

#endif
