#include "diagnosis.hpp"

namespace birthmarc {

std::string Diagnosis::Evaluate(
    const std::string& anamnesis,
    const userver::server::http::HttpRequest &request) {
  return std::getenv("FLAG");
}

}
