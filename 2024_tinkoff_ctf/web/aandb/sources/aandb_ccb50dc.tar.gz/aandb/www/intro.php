<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>А и Б</title>

    <style>
        body {
            background: #000;
            margin: 0;
            overflow: hidden;
        }
        
        .container {
            width: 1000px;
            margin: auto;
            position: relative;
        }
        
        img {
            max-width: 100%;
        }

        .letter {
            width: 64px; 
            height: 64px; 
            position: absolute; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%);
        }

        .letter img {
            animation-duration: 1s;
            animation-delay: 500ms;
            animation-fill-mode: forwards;
        }

        #a {
            transform: translate(-70px, -60px);
            animation-name: tumbleDown;
        }

        #i {
            transform: translate(0, -60px);
            animation-name: shrink;
            animation-duration: 0.5s;
        }

        #b {
            transform: translate(70px, -60px);
            animation-name: fadeOut;
        }

        @keyframes tumbleDown {
            100% {
                transform: translate(-70px, 100vh) rotate(360deg);
            }
        }

        @keyframes shrink {
            100% {
                transform: translate(0, -60px) scaleX(0);
            }
        }

        @keyframes fadeOut {
            100% {
                opacity: 0;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="pipe.png" />
        <div class="letter"><img id="a" src="ico/a.png" /></div>
        <div class="letter"><img id="i" src="ico/i.png" /></div>
        <div class="letter"><img id="b" src="ico/b.png" /></div>
    </div>
    
    <script>
        setTimeout(function () { location.href = '.'; }, 2000);
    </script>
</body>
</html>
