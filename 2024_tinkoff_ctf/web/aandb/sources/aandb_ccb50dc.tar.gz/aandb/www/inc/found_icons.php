<?php
if (file_exists("/tmp/$sessid/aFound")) {
    echo '<div style="width: 64px; height: 64px; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);"><img src="ico/a.png" style="transform: translate(-70px, -60px);" /></div>';
}
if (file_exists("/tmp/$sessid/iFound")) {
    echo '<div style="width: 64px; height: 64px; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);"><img src="ico/i.png" style="transform: translate(0, -60px);" /></div>';
}
if (file_exists("/tmp/$sessid/bFound")) {
    echo '<div style="width: 64px; height: 64px; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);"><img src="ico/b.png" style="transform: translate(70px, -60px);" /></div>';
}
