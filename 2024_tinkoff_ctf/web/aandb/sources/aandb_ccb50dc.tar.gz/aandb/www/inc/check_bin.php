<?php
$idx = (int)$_POST['open'];
if ($idx < 1 || $idx > 2000) {
    redir(".");
}
if (file_exists("/tmp/$sessid/opened/$idx")) {
    redir(".");
}

$error = false;
if (!isset($_POST['token']) || !preg_match('#[A-Za-z0-9_-]{200,}#s', $_POST['token'])) {
    $error = "Пройдите капчу";
} else {
    $token = $_POST['token'];
    $ctx = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => "secret=$TURNSTILE_SECRETKEY&response=$token",
        ]
    ]);
    $res = file_get_contents("https://challenges.cloudflare.com/turnstile/v0/siteverify", null, $ctx);
    $res = json_decode($res, true);
    if (empty($res['success'])) {
        $error = "Капча отклонена Cloudflare Turnstile";
    }
}

if (!empty($error)) {
    echo "<h1>$error</h1>";
} else {
    $objects = [
        ["agent.png", "Агент"],
        ["battery.png", "Батарейка"],
        ["bin_empty.png", "Ещё одна корзина"],
        ["card.png", "Визитка"],
        ["chip.png", "Чип"],
        ["clock.png", "Будильник"],
        ["credit.png", "Кредитка"],
        ["envelope.png", "Конверт"],
        ["junk.png", "Мусор"],
        ["keys.png", "Ключи"],
        ["list.png", "Список"],
        ["monitor.png", "Сломанный монитор"],
        ["mouse.png", "Мышка"],
        ["newspaper.png", "Газета"],
        ["paperclip.png", "Скрепка"],
        ["plushbear.png", "Плюшевый мишка"],
        ["scrap.png", "Обрывок"],
        ["tablet.png", "Планшет"],
        ["umbrella.png", "Зонтик и модем"],
        ["webdoc.png", "Веб-страничка"],
    ];

    if ($idx == file_get_contents("/tmp/$sessid/aPos")) {
        $found = ["a.png", "А"];
        touch("/tmp/$sessid/aFound");
    } elseif ($idx == file_get_contents("/tmp/$sessid/iPos")) {
        $found = ["i.png", "И"];
        touch("/tmp/$sessid/iFound");
    } elseif ($idx == file_get_contents("/tmp/$sessid/bPos")) {
        $found = ["b.png", "Б"];
        touch("/tmp/$sessid/bFound");
    } else {
        $found = $objects[array_rand($objects)];
    }

    touch("/tmp/$sessid/opened/$idx");
    echo "<p>Ваша находка:</p><p><img src='ico/$found[0]' /><br>$found[1]</p>";
}
?>
<h3><a href=".">Роемся дальше →</a></h3>
