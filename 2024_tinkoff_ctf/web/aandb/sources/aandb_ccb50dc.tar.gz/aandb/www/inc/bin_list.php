<h1>На поиски!</h1>
<?php
$left = file_get_contents("/tmp/$sessid/deadline") - time();
$m = floor($left / 60);
$s = $left % 60;
?>
<h3>У вас осталось <?=sprintf("%d мин %02d сек", $m, $s)?></h3>
<?php
for ($idx = 1; $idx <= 2000; $idx++) {
    echo "<a href='?open=$idx'><div class='bin'><img src='ico/" . (file_exists("/tmp/$sessid/opened/$idx") ? "bin_empty.png" : "bin_full.png") . "' /><br><span>$idx</span></div></a>";
}
