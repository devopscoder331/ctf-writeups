<?php
$TURNSTILE_SITEKEY = "0x4AAAAAAAWwubDrsOK0A3Fn";
$TURNSTILE_SECRETKEY = "0x4AAAAAAAWwudXw2k9guU3mpj33UNFToAo";

function redir($url) {
    ob_end_clean();
    header("Location: $url", true, 303);
    exit;
}
