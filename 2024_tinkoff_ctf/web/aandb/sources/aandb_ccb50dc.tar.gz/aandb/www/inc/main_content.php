<?php
if (file_exists("/tmp/$sessid/aFound") && file_exists("/tmp/$sessid/iFound") && file_exists("/tmp/$sessid/bFound")) {
    echo "<h2>tctf{XXXXXXXXXXXXXXXXXXXXXX}</h2>";
}

if (isset($_GET['open'])) {
    require_once 'inc/open_bin.php';
} elseif (isset($_POST['open'])) {
    require_once 'inc/check_bin.php';
} else {
    require_once 'inc/bin_list.php';
}
