<?php
$idx = (int)$_GET['open'];
if ($idx < 1 || $idx > 2000) {
    redir(".");
}
if (file_exists("/tmp/$sessid/opened/$idx")) {
    redir(".");
}
?>
<h1>Роемся в корзине № <?=$idx?></h1>
<p>Подтвердите, что вы не автоматизированный сборщик мусора.</p>
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js"></script>
<div class="cf-turnstile" data-sitekey="<?=$TURNSTILE_SITEKEY?>" data-action="open_bin" data-callback="turnstile_passed" data-error-callback="turnstile_error" data-theme="dark" data-response-field="false"></div>
<form name="openForm" method="POST" action="?">
    <input type="hidden" name="open" value="<?=$idx?>" />
    <input type="hidden" name="token" />
</form>
<script>
    function turnstile_passed(token) {
        openForm.token.value = token;
        openForm.submit();
    }
    
    function turnstile_error() {
        location.reload();
    }
</script>
