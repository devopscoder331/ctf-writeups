<?php
error_reporting(0);
ob_start();

if (isset($_COOKIE['sessid']) && preg_match('#^[a-f0-9]{32}$#s', $_COOKIE['sessid'])) {
    $sessid = $_COOKIE['sessid'];
} else {
    $sessid = bin2hex(random_bytes(16));
    setcookie("sessid", $sessid);
}

if (!is_dir("/tmp/$sessid/")) {
    mkdir("/tmp/$sessid/");
    [$aPos, $iPos, $bPos] = array_rand(range(0, 2000 - 1), 3);
    file_put_contents("/tmp/$sessid/aPos", $aPos + 1);
    file_put_contents("/tmp/$sessid/iPos", $iPos + 1);
    file_put_contents("/tmp/$sessid/bPos", $bPos + 1);
    mkdir("/tmp/$sessid/opened");
    file_put_contents("/tmp/$sessid/deadline", time() + 5 * 60);
    redir("intro.php");
}

if (time() > file_get_contents("/tmp/$sessid/deadline")) {
    system("rm -rf " . escapeshellarg("/tmp/$sessid"));
    redir(".");
}
