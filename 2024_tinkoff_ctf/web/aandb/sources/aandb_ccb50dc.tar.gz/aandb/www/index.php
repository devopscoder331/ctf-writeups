<?php
require_once 'inc/functions.php';
require_once 'inc/init.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>А и Б</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <img src="pipe.png" />
        <?php require_once 'inc/found_icons.php'; ?>
    </div>
    <div class="container">
        <center>
            <?php require_once 'inc/main_content.php'; ?>
        </center>
    </div>
</body>
</html>
