#!/bin/sh

python manage.py makemigrations core --noinput
python manage.py migrate --noinput
python manage.py collectstatic --noinput
python manage.py loaddata data.json

exec "$@"