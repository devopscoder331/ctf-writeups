from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.mixins import UserPassesTestMixin, LoginRequiredMixin
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.urls import reverse, reverse_lazy
from django.views.generic import CreateView, FormView, UpdateView
from django_filters.views import FilterView

from core.models import User, Comment, Parameter
from core import forms, filters
from core.utils import AdminRequiredMixin


class UserCreateView(UserPassesTestMixin, CreateView):
    form_class = forms.RegisterForm
    model = User
    success_url = reverse_lazy('index')

    def test_func(self):
        return self.request.user.is_anonymous

    def handle_no_permission(self):
        return redirect(reverse_lazy('index'))

    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        return redirect(self.success_url)


class UserUpdateView(LoginRequiredMixin, UpdateView):
    form_class = forms.UserUpdateForm
    model = User
    template_name = 'core/profile.html'
    success_url = reverse_lazy('profile')

    def get_object(self, queryset=None):
        return self.request.user


class IndexView(CreateView):
    form_class = forms.CommentForm
    model = Comment
    success_url = reverse_lazy('index')
    template_name = 'core/index.html'

    def form_valid(self, form):
        form.instance.user = self.request.user
        form.instance.page = 'index'
        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        kwargs['comments'] = Comment.objects.filter(page='index').select_related('user').order_by('-id')[:30]
        return super(IndexView, self).get_context_data(**kwargs)


class ParameterView(CreateView):
    form_class = forms.ParameterForm
    model = Parameter
    success_url = reverse_lazy('parameters')
    template_name = 'core/parameters.html'

    def get_context_data(self, **kwargs):
        kwargs['parameters'] = Parameter.objects.exclude(name='DEBUG_KEY')
        return super(ParameterView, self).get_context_data(**kwargs)


class UserView(AdminRequiredMixin, FilterView):
    filterset_class = filters.UserFilter
    model = User
    template_name = 'core/users.html'


class FunctionsView(CreateView):
    form_class = forms.CommentForm
    model = Comment
    success_url = reverse_lazy('functions')
    template_name = 'core/functions.html'

    def form_valid(self, form):
        form.instance.user = self.request.user
        form.instance.page = 'functions'
        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        kwargs['comments'] = Comment.objects.filter(page='functions').select_related('user').order_by('-id')[:30]
        return super(FunctionsView, self).get_context_data(**kwargs)


class ConvertView(FormView):
    template_name = 'core/convert.html'
    form_class = forms.ConvertForm
    success_url = reverse_lazy('convert')

    def form_valid(self, form):
        return form.cleaned_data['file']
