import tempfile
import urllib.parse
from pathlib import Path

import requests
import io
import pypandoc

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator
from django.http import HttpResponse

from core.models import User, Comment, Parameter
from core.utils import resize_uploaded_image


class RegisterForm(UserCreationForm):

    class Meta:
        model = User
        fields = ["username", "first_name", "last_name", "password1", "password2", ]


class UserUpdateForm(forms.ModelForm):
    avatar_url = forms.URLField(label="Или укажите URL аватара", required=False)
    avatar = forms.ImageField(label="Загрузите картинку", required=False)

    class Meta:
        model = User
        fields = ["first_name", "last_name", "avatar"]

    def clean(self):
        cleaned_data = super().clean()
        if cleaned_data.get('avatar') and cleaned_data.get('avatar_url'):
            raise ValidationError({'avatar': 'Можно выбрать либо картинку, либо URL'})
        if cleaned_data.get('avatar_url'):
            url = cleaned_data.get('avatar_url')
            if not any([url.endswith(ext) for ext in ['.jpg', '.jpeg', '.gif', '.png']]):
                raise ValidationError({'avatar_url': 'Неизвестное расширение'})
            try:
                data = requests.get(url, timeout=30).content
                image = io.BytesIO(data)
            except Exception as e:
                print(e)
                raise ValidationError({'avatar_url': 'Не удалось загрузить аватар'})
        else:
            image = self.cleaned_data.get('avatar')
        if image:
            try:
                image = resize_uploaded_image(image, 250, 250)
                cleaned_data['avatar'] = image
            except Exception as e:
                print(e)
                raise ValidationError({'avatar_url': 'Не удалось сохранить аватар'})

        return cleaned_data


class CommentForm(forms.ModelForm):
    text = forms.CharField(label="Текст")

    class Meta:
        model = Comment
        fields = ['text']


class ParameterForm(forms.ModelForm):

    class Meta:
        model = Parameter
        fields = ['name', 'value']


class ConvertForm(forms.Form):
    file = forms.FileField(label='Файл',
                           validators=[FileExtensionValidator(['doc', 'docx', 'dot']), ],
                           widget=forms.FileInput(attrs={'accept': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'}))

    def clean_file(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            data = self.cleaned_data['file']
            name, ext = data.name.rsplit('.', 1)
            input_path = Path(tmp_dir).joinpath(f'input.{ext}')
            with open(input_path, 'wb') as input_file:
                input_file.write(data.read())
            output_path = Path(tmp_dir).joinpath(f'output.odt')
            try:
                pypandoc.convert_file(input_path, 'odt', format=ext, outputfile=output_path, extra_args=['-M creator=Умный Офис'])
            except Exception:
                raise ValidationError('Не удалось конвертировать файл')
            response = HttpResponse(open(output_path, 'rb').read(), content_type="application/vnd.oasis.opendocument.text")
            response['Content-Disposition'] = f"attachment; filename*=UTF-8''{urllib.parse.quote_plus(name)}.odt"
            return response
