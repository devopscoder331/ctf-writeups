from django.contrib.auth.models import AbstractUser
from django.db import models


def user_directory_path(instance, filename):
    return f"user_{instance.id}/{filename}"


class User(AbstractUser):
    avatar = models.ImageField(upload_to=user_directory_path, null=True, blank=True)


class Comment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    page = models.CharField(blank=False, null=False, max_length=128)
    text = models.TextField(blank=False, null=False, max_length=1024)


class Parameter(models.Model):
    name = models.CharField(max_length=128, unique=True)
    value = models.CharField(max_length=1024)
