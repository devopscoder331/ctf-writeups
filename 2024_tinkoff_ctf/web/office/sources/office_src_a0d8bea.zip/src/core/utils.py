import os
from io import BytesIO
from PIL import Image as PilImage
from django.contrib.auth.mixins import AccessMixin
from django.core.files.base import ContentFile
from django.core.files.uploadedfile import InMemoryUploadedFile, TemporaryUploadedFile


def resize_uploaded_image(image, max_width, max_height):
    size = (max_width, max_height)

    # Uploaded file is in memory
    if isinstance(image, InMemoryUploadedFile):
        memory_image = BytesIO(image.read())
        name = image.name
        pil_image = PilImage.open(memory_image)
        img_format = os.path.splitext(name)[1][1:].upper()
        img_format = 'JPEG' if img_format == 'JPG' else img_format

        if pil_image.width > max_width or pil_image.height > max_height:
            pil_image.thumbnail(size)

        new_image = BytesIO()
        pil_image.save(new_image, format=img_format)

        new_image = ContentFile(new_image.getvalue())
        return InMemoryUploadedFile(new_image, None, name, image.content_type, None, None)

    # Uploaded file is in disk
    elif isinstance(image, TemporaryUploadedFile):
        path = image.temporary_file_path()
        pil_image = PilImage.open(path)

        if pil_image.width > max_width or pil_image.height > max_height:
            pil_image.thumbnail(size)
            pil_image.save(path)
            image.size = os.stat(path).st_size
        return image

    elif isinstance(image, BytesIO):
        pil_image = PilImage.open(image)
        if pil_image.width > max_width or pil_image.height > max_height:
            pil_image.thumbnail(size)
        img_format = pil_image.format
        mime = pil_image.get_format_mimetype()
        new_image = BytesIO()
        pil_image.save(new_image, format=img_format)
        new_image = ContentFile(new_image.getvalue())
        name = f"avatar.{img_format.lower()}"
        return InMemoryUploadedFile(new_image, None, name, mime, None, None)


class AdminRequiredMixin(AccessMixin):

    def dispatch(self, request, *args, **kwargs):
        x_forwarded_for = request.META.get('HTTP_X_REAL_IP')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')
        if not (request.user.is_staff or ip == '127.0.0.1'):
            return self.handle_no_permission()
        return super().dispatch(request, *args, **kwargs)
