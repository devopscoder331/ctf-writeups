import django_filters as filters
from django.db.models.functions import Extract

from core.models import User


class UserFilter(filters.FilterSet):
    username = filters.CharFilter(lookup_expr='icontains')
    first_name = filters.CharFilter(lookup_expr='icontains')
    last_name = filters.CharFilter(lookup_expr='icontains')
    joined = filters.CharFilter(label='Присоединился', method='filter_joined')

    def filter_joined(self, queryset, name, value):
        if value:
            queryset = queryset.annotate(date_joined_extract=Extract('date_joined', value))
        return queryset

    class Meta:
        model = User
        order_by_field = '-id'
        fields = ['username', 'first_name', 'last_name', 'joined']
