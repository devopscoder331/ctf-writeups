rm client.key client.crt client.csr
rm server.key server.crt server.csr
rm ca.key ca.srl ca.crt 

