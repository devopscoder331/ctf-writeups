from passlib.context import CryptContext
from sqlalchemy import Boolean, Column, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.database import Base

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    password = Column(String)

    def verify_password(self, plain_password):
        return pwd_context.verify(plain_password, self.password)


class Note(Base):
    __tablename__ = "notes"

    id = Column(Integer, primary_key=True, index=True)
    owner_id = Column(Integer, ForeignKey("users.id"))
    text = Column(Text, nullable=True)
    owner = relationship("User", back_populates="notes")
    encrypted = Column(Boolean, default=False)
    archive_path = Column(String, nullable=True)


class Image(Base):
    __tablename__ = "images"

    id = Column(Integer, primary_key=True, index=True)
    note_id = Column(Integer, ForeignKey("notes.id"))
    path = Column(String, nullable=False)
    note = relationship("Note", back_populates="images")


User.notes = relationship("Note", order_by=Note.id, back_populates="owner")
Note.images = relationship("Image", order_by=Image.id, back_populates="note")


def get_password_hash(password):
    return pwd_context.hash(password)
