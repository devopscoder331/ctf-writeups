from typing import List

from fastapi import (APIRouter, Depends, File, Form, HTTPException, Request,
                     UploadFile, status)
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.crud import (authenticate_user, create_note, create_user,
                      encrypt_note, get_note_by_id, get_user_by_username,
                      save_image)
from app.database import SessionLocal
from app.schemas import UserCreate
from app.templates import templates

router = APIRouter()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/register", response_class=HTMLResponse)
async def register(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})


@router.post("/register")
async def register_user(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    try:
        db_user = create_user(
            db=db, user=UserCreate(username=username, password=password)
        )
        if db_user:
            return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    except Exception as e:
        message = str(e)
    return templates.TemplateResponse(
        "register.html", {"request": request, "msg": message}
    )


@router.get("/login", response_class=HTMLResponse)
async def login(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@router.post("/login")
async def login_user(
    request: Request,
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db),
):
    user = authenticate_user(
        db=db, username=form_data.username, password=form_data.password
    )
    if not user:
        message = "Неверные имя пользователя или пароль"
        return templates.TemplateResponse(
            "login.html", {"request": request, "msg": message}
        )

    request.session["user"] = user.username
    return RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)


@router.get("/logout")
def logout(request: Request):
    request.session.pop("user", None)
    return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)


@router.get("/", response_class=HTMLResponse)
async def profile(request: Request, db: Session = Depends(get_db)):
    username = request.session.get("user")
    if username is None:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    user = get_user_by_username(db, username)
    if user is None:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    return templates.TemplateResponse(
        "profile.html", {"request": request, "user": user}
    )


@router.get("/new", response_class=HTMLResponse)
async def add_new_note_form(request: Request, db: Session = Depends(get_db)):
    username = request.session.get("user")
    if username is None:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    user = get_user_by_username(db, username)
    if user is None:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    return templates.TemplateResponse(
        "new_note.html", {"request": request, "user": user}
    )


@router.post("/new")
async def add_new_note(
    request: Request,
    text: str = Form(...),
    images: List[UploadFile] = File(...),
    db: Session = Depends(get_db),
):
    username = request.session.get("user")
    if username is None:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    user = get_user_by_username(db, username)
    if user is None:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    note = create_note(db, user.id, text)

    for image in images:
        if image.size == 0:
            continue
        save_image(db, image, note.id)

    return RedirectResponse(url=f"/note/{note.id}", status_code=status.HTTP_302_FOUND)


@router.get("/note/{id}", response_class=HTMLResponse)
async def read_note(request: Request, id: int, db: Session = Depends(get_db)):
    username = request.session.get("user")
    if username:
        user = get_user_by_username(db, username)
    else:
        user = None

    note = get_note_by_id(db, id)
    if note is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Материалы не найдены"
        )

    is_owner = (
        "user" in request.session and request.session.get("user") == note.owner.username
    )

    return templates.TemplateResponse(
        "note.html",
        {"request": request, "note": note, "is_owner": is_owner, "user": user},
    )


@router.post("/encrypt/{id}")
async def encrypt_note_by_id(request: Request, id: int, db: Session = Depends(get_db)):
    note = get_note_by_id(db, id)
    if note is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Материалы не найдены"
        )

    if note.encrypted:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Материалы уже зашифрованы"
        )

    username = request.session.get("user")
    if username is None:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    user = get_user_by_username(db, username)
    if user is None:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    is_owner = username == note.owner.username

    if not is_owner:
        raise HTTPException(
            status_code=401, detail="Требуется войти под аккаунтом владельца"
        )

    archive_path, password = encrypt_note(db, note)
    return {"password": password, "archive": archive_path}
