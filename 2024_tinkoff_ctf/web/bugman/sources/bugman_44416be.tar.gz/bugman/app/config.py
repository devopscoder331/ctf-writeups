import os
from functools import lru_cache

from dotenv import load_dotenv
from pydantic_settings import BaseSettings

load_dotenv()


class Settings(BaseSettings):
    secret_key: str = os.getenv("SECRET_KEY")
    db_name: str
    db_user: str
    db_password: str
    db_host: str
    db_port: int
    uploads_path: str = "app/static/uploads"

    class Config:
        env_prefix = "BUGMAN_"
        env_file = ".env"

    @property
    def database_uri(self) -> str:
        return f"postgresql://{self.db_user}:{self.db_password}@{self.db_host}:{self.db_port}/{self.db_name}"


@lru_cache()
def get_settings():
    return Settings()


settings = get_settings()
