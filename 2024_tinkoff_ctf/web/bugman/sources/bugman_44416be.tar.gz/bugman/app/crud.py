import base64
import os
import random
import shutil
import string
import uuid
import zipfile
from hashlib import md5
from typing import Literal

import pyminizip
from config import settings
from fastapi import UploadFile
from sqlalchemy.orm import Session

from app.models import Image, Note, User, get_password_hash
from app.schemas import UserCreate


def get_user_by_username(db: Session, username: str) -> User:
    return db.query(User).filter(User.username == username).first()


def create_user(db: Session, user: UserCreate) -> User:
    if len(user.password) < 9 or len(user.password) < 9:
        raise ValueError(
            "Длина имени пользователя и пароля должна быть не меньше 9 символов"
        )

    if get_user_by_username(db, user.username):
        raise ValueError("Пользователь с таким имененм уже зарегистрирован")

    hashed_password = get_password_hash(user.password)
    db_user = User(username=user.username, password=hashed_password)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def authenticate_user(
    db: Session, username: str, password: str
) -> User | Literal[False]:
    user = get_user_by_username(db, username)
    if not user:
        return False
    if not user.verify_password(password):
        return False
    return user


def create_note(db: Session, owner_id: int, text: str) -> Note:
    db_note = Note(owner_id=owner_id, text=text)
    db.add(db_note)
    db.commit()
    db.refresh(db_note)
    return db_note


def save_image(db: Session, file: UploadFile, note_id: int) -> Image:
    filename = f"{uuid.uuid4().hex}_{file.filename}"
    filepath = f"{settings.uploads_path}/{filename}"

    with open(filepath, "wb") as b:
        shutil.copyfileobj(file.file, b)

    db_image = Image(note_id=note_id, path=filename)

    db.add(db_image)
    db.commit()
    db.refresh(db_image)
    return db_image


def get_note_by_id(db: Session, id: int) -> Note:
    return db.query(Note).filter(Note.id == id).first()


def encrypt_note(db: Session, note: Note):
    random_password = "".join(
        random.choices(string.ascii_letters + string.digits, k=30)
    )
    password = base64.b64encode(
        md5(random_password.encode()).hexdigest()[:6].encode()
    ).decode()

    zip_filename = f"{note.id}_{''.join(random.choices(string.ascii_letters + string.digits, k=6))}.zip"
    zip_filepath = os.path.join(settings.uploads_path, zip_filename)

    temp_note_text_path = os.path.join("/tmp", f"note_{note.id}.txt")
    with open(temp_note_text_path, "w") as note_file:
        note_file.write(note.text)

    files_to_zip = [temp_note_text_path]

    for image in note.images:
        image_path = os.path.join(settings.uploads_path, image.path)
        files_to_zip.append(image_path)

    pyminizip.compress_multiple(files_to_zip, [], zip_filepath, password, 5)

    for image in note.images:
        image_path = os.path.join(settings.uploads_path, image.path)
        os.remove(image_path)
        db.delete(image)

    os.remove(temp_note_text_path)

    note.encrypted = True
    note.archive_path = zip_filename
    note.text = ""
    db.add(note)
    db.commit()

    return zip_filename, password
