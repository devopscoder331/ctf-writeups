import uvicorn
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

from app.config import settings
from app.database import engine
from app.models import Base
from app.views import router

Base.metadata.create_all(bind=engine)

app = FastAPI()


@app.middleware("http")
async def add_user_to_request(request: Request, call_next):
    request.state.user = None
    username = request.session.get("user")

    if username:
        request.state.user = {"username": username}

    response = await call_next(request)
    return response


app.add_middleware(SessionMiddleware, secret_key=settings.secret_key)

app.include_router(router)

app.mount("/static", StaticFiles(directory="app/static"), name="static")


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, workers=4)
