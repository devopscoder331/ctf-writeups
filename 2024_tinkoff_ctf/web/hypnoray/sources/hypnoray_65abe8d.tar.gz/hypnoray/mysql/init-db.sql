CREATE TABLE IF NOT EXISTS Users (
    id INT PRIMARY KEY auto_increment,
    login VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);
CREATE TABLE IF NOT EXISTS Checkpoints (
    id INT PRIMARY KEY auto_increment,
    userid int,
    item text,
    FOREIGN KEY (userid) REFERENCES Users(id)
);
INSERT INTO Users (login, password) VALUES ('dr.cosmodinamikov', 'bf48b7805dad4debdb7d28f0ce69dac5306e1822');
INSERT INTO Checkpoints (userid, item) VALUES (1, 'tctf{testflag}');