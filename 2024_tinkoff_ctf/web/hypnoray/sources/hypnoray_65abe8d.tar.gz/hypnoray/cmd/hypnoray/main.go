package main

import (
	"fmt"
	"hypnoray/internal/controllers"
	"hypnoray/internal/db"
	"hypnoray/internal/middleware"
	"net/http"

	log "github.com/sirupsen/logrus"
	"github.com/spf13/viper"

	"github.com/gin-contrib/sessions"
	"github.com/gin-contrib/sessions/cookie"
	"github.com/gin-gonic/gin"
)

func init() {
	viper.SetEnvPrefix("hypnoray")
	viper.AutomaticEnv()
}
func registerRoutes(router *gin.Engine) {
	unauthorized := router.Group("/")
	unauthorized.GET("/login", func(c *gin.Context) {
		c.HTML(http.StatusOK, "login", nil)
	})
	unauthorized.GET("/register", func(c *gin.Context) {
		c.HTML(http.StatusOK, "register", nil)
	})

	unauthorized.POST("/login", controllers.Login)
	unauthorized.POST("/register", controllers.Register)

	auth := router.Group("/")
	auth.Use(middleware.CheckAuth)
	auth.GET("/", controllers.ListCheckpoint)
	auth.POST("/", controllers.AddCheckpoint)
	auth.GET("/change", func(c *gin.Context) {
		c.HTML(http.StatusOK, "changePassword", nil)
	})
	auth.POST("/change", controllers.ChangePassword)
	auth.GET("/logout", controllers.Logout)

	log.Println("Routes added!")
}

func main() {
	dbConfig := db.GetDbConfig()
	dsn := fmt.Sprintf("%s:%s@tcp(%s:3306)/%s", dbConfig.User, dbConfig.Password, dbConfig.Host, dbConfig.DBName)
	db, err := db.DbConn(dsn)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	gin.SetMode(gin.ReleaseMode)
	router := gin.Default()
	router.LoadHTMLGlob("templates/*.html")
	store := cookie.NewStore([]byte(viper.GetString("SECRETKEY")))
	router.Use(sessions.Sessions("session", store))
	router.Use(func(c *gin.Context) {
		c.Set("db", db)
		c.Next()
	})
	registerRoutes(router)
	log.Println("Start listen 8080")
	router.Run(":8080")

}
