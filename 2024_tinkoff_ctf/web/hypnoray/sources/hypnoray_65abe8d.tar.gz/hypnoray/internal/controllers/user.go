package controllers

import (
	"context"
	"database/sql"
	helpers "hypnoray/internal/lib"
	"log"
	"net/http"
	"time"

	"github.com/gin-contrib/sessions"
	"github.com/gin-gonic/gin"
)

func Login(c *gin.Context) {
	db := c.MustGet("db").(*sql.DB)

	login := c.PostForm("login")
	password := c.PostForm("password")
	if login == "" || password == "" {
		c.HTML(http.StatusUnprocessableEntity, "login", gin.H{"message": "Enter login and password"})
	}
	hashedPassword, err := helpers.GenerateHash(password)
	if err != nil {
		log.Fatal(err)
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	row := db.QueryRowContext(ctx, "SELECT id, password FROM Users WHERE login = ? AND password = ? LIMIT 1", login, hashedPassword)
	var userHash string
	var userID int
	switch err := row.Scan(&userID, &userHash); err {
	case nil:
	case sql.ErrNoRows:
		c.HTML(http.StatusOK, "login", gin.H{"message": "Invalid login or password!"})
		return
	default:
		log.Fatal(err)
	}
	session := sessions.Default(c)
	session.Set("userID", userID)
	session.Save()
	c.Redirect(http.StatusFound, "/")
}

func Register(c *gin.Context) {
	db := c.MustGet("db").(*sql.DB)
	login := c.PostForm("login")
	password := c.PostForm("password")
	if len(login) < 6 || len(password) < 8 || login == "dr.cosmodinamikov" {
		c.HTML(http.StatusUnprocessableEntity, "register", gin.H{"message": "Enter login and password"})
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	hashedPassword, err := helpers.GenerateHash(password)
	if err != nil {
		log.Fatal(err)
		return
	}

	_, err = db.ExecContext(ctx, "INSERT INTO Users (login, password) VALUES (?, ?)", login, hashedPassword)
	if err != nil {
		log.Fatal(err)
		c.HTML(http.StatusBadRequest, "register", gin.H{"message": "Failed to create user"})
		return
	}
	c.Redirect(http.StatusFound, "/login")
}

func Logout(c *gin.Context) {
	defer c.Redirect(http.StatusFound, "/login")
	session := sessions.Default(c)
	session.Clear()
	err := session.Save()
	if err != nil {
		return
	}
}

func ChangePassword(c *gin.Context) {
	db := c.MustGet("db").(*sql.DB)
	password := c.PostForm("password")
	session := sessions.Default(c)
	userID := session.Get("userID")
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	if len(password) < 8 {
		c.HTML(http.StatusOK, "changePassword", gin.H{"message": "Wrong new password", "userid": userID})
	}
	hashedPassword, err := helpers.GenerateHash(password)
	if err != nil {
		log.Fatal(err)
		return
	}
	row := db.QueryRowContext(ctx, "SELECT login FROM Users WHERE id = ? LIMIT 1", userID)
	var username string
	switch err := row.Scan(&username); err {
	case nil:
	case sql.ErrNoRows:
		c.HTML(http.StatusOK, "changePassword", gin.H{"message": "Invalid login or password!", "userid": userID})
		return
	default:
		log.Fatal(err)
	}
	_, err = db.ExecContext(ctx, "UPDATE Users SET password = ? WHERE login = ?", hashedPassword, username)
	if err != nil {
		log.Fatal(err)
		c.HTML(http.StatusBadRequest, "changePassword", gin.H{"message": "Failed to change password", "userid": userID})
		return
	}
	c.HTML(http.StatusOK, "changePassword", gin.H{"message": "Password changed", "userid": userID})

	return
}
