package controllers

import (
	"context"
	"database/sql"
	"log"
	"net/http"
	"time"

	"github.com/gin-contrib/sessions"
	"github.com/gin-gonic/gin"
)

func ListCheckpoint(c *gin.Context) {
	db := c.MustGet("db").(*sql.DB)
	var res string
	var checkpoints []string
	session := sessions.Default(c)
	userID := session.Get("userID")
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	rows, err := db.QueryContext(ctx, "SELECT item FROM Checkpoints WHERE userid = ?", userID)
	if err != nil {
		log.Fatalln()
		c.HTML(http.StatusInternalServerError, "profile", gin.H{"message": "No items", "userid": userID})
		return
	}
	for rows.Next() {
		rows.Scan(&res)
		checkpoints = append(checkpoints, res)
	}

	c.HTML(http.StatusOK, "profile", gin.H{"Todos": checkpoints, "userid": userID})
	return
}

func AddCheckpoint(c *gin.Context) {
	db := c.MustGet("db").(*sql.DB)
	item := c.PostForm("Item")
	session := sessions.Default(c)
	userID := session.Get("userID")
	if item != "" {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancel()
		_, err := db.ExecContext(ctx, "INSERT INTO Checkpoints (userid, item) VALUES (?, ?)", userID, item)
		if err != nil {
			log.Fatalf("An error occured while executing query: %v", err)
		}
	}
	c.Redirect(http.StatusFound, "/")
	return
}
