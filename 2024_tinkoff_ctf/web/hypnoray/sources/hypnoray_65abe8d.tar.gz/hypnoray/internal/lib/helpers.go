package helpers

import (
	"crypto/sha1"
	"fmt"
)

func GenerateHash(passwd string) (string, error) {
	h := sha1.New()
	h.Write([]byte(passwd))
	result := fmt.Sprintf("%x", h.Sum(nil))
	return result, nil
}
