package db

import (
	"database/sql"

	_ "github.com/go-sql-driver/mysql"
	"github.com/spf13/viper"
)

type dbConfig struct {
	Host     string
	Port     int
	User     string
	Password string
	DBName   string
}

func GetDbConfig() *dbConfig {
	return &dbConfig{
		Host:     viper.GetString("DB_HOST"),
		Port:     viper.GetInt("DB_PORT"),
		User:     viper.GetString("DB_USER"),
		Password: viper.GetString("DB_PASSWORD"),
		DBName:   viper.GetString("DB_NAME"),
	}
}

func DbConn(dsn string) (db *sql.DB, err error) {
	db, err = sql.Open("mysql", dsn)
	if err != nil {
		return nil, err
	}
	db.SetConnMaxIdleTime(10)

	if err = db.Ping(); err != nil {
		return nil, err
	}
	return db, nil
}
