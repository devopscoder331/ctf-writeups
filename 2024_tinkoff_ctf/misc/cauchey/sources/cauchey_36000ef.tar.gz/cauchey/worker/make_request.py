from openai import OpenAI
from html import escape
import redis
import uuid
from html import escape
import json
import utils
import random
import os
import re
import ast
import string
from chess import check_path
import shutil
import ast

def is_code(input_string):
    try:
        ast.parse(input_string)
        return True
    except SyntaxError:
        return False

letters = string.ascii_uppercase
# Generate 10 random alphanumeric characters
def random_string(n=20):
    return ''.join(random.choices(letters + string.digits, k=n))


r = redis.Redis(host='redis', port=6379, db=0)


def update_message(username, message_id, response=None, result=None, result_message=None):
    """Update a specific chat message in its hash."""
    hash_key = f"user:{username}:message:{message_id}"
    if response:
        r.hset(hash_key, 'response', response)
    if result is not None:
        r.hset(hash_key, 'result', str(result))
        r.hset(hash_key, 'completed', 'True')
    if result_message:
        r.hset(hash_key, 'result_message', result_message)


def remove_code_markers(text):
    # Remove the opening and closing code block markers
    lines = text.split('\n')
    cleaned_lines = [line for line in lines if line.strip() not in {'```python', '```'}]
    return '\n'.join(cleaned_lines)


def queued_job(message, author, message_id, tokens):
    ai_response = ai_request(message, author, message_id)
    ai_response = remove_code_markers(ai_response)
    if not is_code(ai_response):
        update_message(username=author, message_id=message_id, response=ai_response, result="False")
        return False
    result, folder = run_code(ai_response)
    if result["StatusCode"] != 0:
        update_message(username=author, message_id=message_id, result="False", result_message=result.get("Error"))
        shutil.rmtree(f'/opt/tasks/{folder}')
        return False
    result, message = checker(folder)
    update_message(username=author, message_id=message_id, result=result, result_message=message)
    shutil.rmtree(f'/opt/tasks/{folder}')
    if not result:
        return False
    r.zadd('scoreboard', {author: tokens})
    return True


def checker(folder):
    file_name = f'/opt/tasks/{folder}/results.txt'
    with open(file_name, 'r') as file:
        for line in file:
            match = re.match(r'^([A-Z][1-9][0-9]?) ([A-Z][1-9][0-9]?) (\[.*\])$', line)
            if not match:
                return False, f"Результат работы не похож на список координат пути: {line}"
            start = match.group(1)
            end = match.group(2)
            path_str = match.group(3)
            try:
                path = ast.literal_eval(path_str)
            except SyntaxError:
                return False, f"Список координат пути не является валидным списком Python: {line}"
            result, message = check_path(start, end, path)
            print(f"For {start} to {end}: {message}")
            if not result:
                return False, message
    return True, "Все пути успешно прошли проверку"


def ai_request(message, author, message_id):
    client = OpenAI(
            api_key=os.environ.get("OPENAI_API_KEY"),
        )
    chat_message = {"messages":[]}
    chat_message["messages"].append({"role": "system", "content": """Your goal is to output only the code that can be interpreted for the following prompt. Do not output any other text except code. If its not possible to output only the code, output a reason"""})
    chat_message["messages"].append({"role": "user", "content": message})
    print(chat_message["messages"])
    chat_completion = client.chat.completions.create(
        messages=chat_message["messages"],
        model="gpt-3.5-turbo-0125",
        temperature=0.2
    )
    update_message(author, message_id, chat_completion.choices[0].message.content)
    result = chat_completion.choices[0].message.content
    print(result)
    return result


def run_code(result):
    folder = random_string()
    if not os.path.exists('/opt/tasks'):
        os.mkdir('/opt/tasks')
    os.mkdir(f'/opt/tasks/{folder}')
    create_target_file("code.py", folder, result)
    create_input_file("input.txt", folder)
    #get current directory
    result = utils.run_container(volume=f"{os.getenv('HOST_DIR')}/tasks/{folder}:/tmp/{folder}", folder=folder)
    return result, folder

def create_target_file(filename_code, folder, result):
    with open(f'/opt/tasks/{folder}/{filename_code}', 'w') as file:
        file.write(result)


def create_input_file(filename_input, folder):
    with open(f'/opt/tasks/{folder}/{filename_input}', 'w') as file:
        for _ in range(5):
            file.write(f"{random.choice(letters)}{random.randint(1, 26)} {random.choice(letters)}{random.randint(1, 26)}\n")
