from collections import deque

def is_within_board(x, y, size=26):
    # Check if the position is within the bounds of the board.
    return 0 <= x < size and 0 <= y < size

def valid_knight_move(x1, y1, x2, y2):
    return (abs(x1 - x2), abs(y1 - y2)) in [(2, 1), (1, 2)]


def position_to_index(pos):
    # Converts board labels to zero-indexed array coordinates.
    column, row = pos[0], pos[1:]
    return (ord(column) - ord('A'), int(row) - 1)

def index_to_position(x, y):
    # Converts zero-indexed array coordinates back to board labels.
    return f"{chr(x + ord('A'))}{y + 1}"



def knight_moves(x, y):
    # Generate all possible knight moves from a given position.
    for dx, dy in [(-2, -1), (-1, -2), (1, -2), (2, -1), (2, 1), (1, 2), (-1, 2), (-2, 1)]:
        nx, ny = x + dx, y + dy
        if is_within_board(nx, ny):
            yield (nx, ny)

def bfs_shortest_path(start, end):
    # Convert the start and end positions to board indices.
    start_x, start_y = position_to_index(start)
    end_x, end_y = position_to_index(end)

    # Initialize BFS
    queue = deque([(start_x, start_y, 0)])  # (current_x, current_y, distance)
    visited = set()
    visited.add((start_x, start_y))

    # Execute BFS
    while queue:
        current_x, current_y, dist = queue.popleft()
        
        # Check if we've reached the target position.
        if (current_x, current_y) == (end_x, end_y):
            return dist

        # Explore all valid knight moves.
        for nx, ny in knight_moves(current_x, current_y):
            if (nx, ny) not in visited:
                visited.add((nx, ny))
                queue.append((nx, ny, dist + 1))
    
    return -1, "Было сложно, но путь не существует."


def check_path(start, end, path):
    start = start.upper()
    end = end.upper()
    # Convert path from notation to indices
    path_indices = [(ord(pos[0]) - ord('a'), int(pos[1:]) - 1) for pos in path]

    # Check initial and final positions
    if path_indices[0] != (ord(start[0]) - ord('a'), int(start[1:]) - 1) or path_indices[-1] != (ord(end[0]) - ord('a'), int(end[1:]) - 1):
        return False, f"Путь не начинается или не заканчивается выданными точками {start} и {end}: {path}"

    # Check all moves are valid
    for i in range(len(path_indices) - 1):
        if not valid_knight_move(path_indices[i][0], path_indices[i][1], path_indices[i+1][0], path_indices[i+1][1]):
            return False, f"Путь {path} содержит некорректный переход от {path[i]} в {path[i+1]}. (Выданные точки: {start} и {end})"

    # Check if path length is the shortest possible
    shortest_path_length = bfs_shortest_path(start, end)
    if len(path) - 1 != shortest_path_length:
        return False, f"Путь {path} не кратчайший. Ожидаемая длина {shortest_path_length}, предложенная длина {len(path) - 1}. (Выданные точки: {start} и {end})"

    return True, "Путь корректен и кратчайший."
