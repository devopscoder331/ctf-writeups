import docker
import os

client = docker.from_env()

def build_docker_image(build_path, image_name, image_tag="latest"):
    """
    Build a Docker image from a Dockerfile.
    :param build_path: Path to the directory containing the Dockerfile.
    :param tag: Tag to assign to the built image.
    """
    # Diagnostic checks
    if not os.path.isdir(build_path):
        print(f"Error: {build_path} is not a directory or does not exist.")
        return False
    if not os.path.exists(os.path.join(build_path, 'Dockerfile')):
        print(f"Error: No Dockerfile found in {build_path}.")
        return False

    try:
        image, build_log = client.images.build(path=build_path, tag=f"{image_name}:{image_tag}")
        for line in build_log:
            if 'stream' in line:
                print(line['stream'].strip())
        print(f"Successfully built {image_name}:{image_tag}")
        return True
    except docker.errors.BuildError as build_error:
        for line in build_error.build_log:
            if 'stream' in line:
                print(line['stream'].strip())
        raise
    except Exception as e:
        print(f"Failed to build image: {e}")
        raise


def is_image_built(image_name, tag='latest'):
    """
    Check if a Docker image with the specified name and tag is already built.
    :param image_name: The name of the Docker image.
    :param tag: The tag of the Docker image. Defaults to 'latest'.
    :return: True if the image is found, False otherwise.
    """
    client = docker.from_env()
    images = client.images.list()
    
    for image in images:
        # Each image object may have multiple tags
        for image_tag in image.tags:
            # Image tags are in the format 'repository:tag'
            repo, image_tag = image_tag.split(':')
            if repo == image_name and image_tag == tag:
                return True

    build_docker_image("docker_container/","py_sandbox") 
    return False


def run_container(volume=None, folder=None):
    """
    Run a Docker container from an image.
    :param image_name: The name of the image to run.
    :param image_tag: The tag of the image to run. Defaults to 'latest'.
    """
    is_image_built("py_sandbox")
    if volume:
        host_volume_path, container_volume_path = volume.split(":")
        volumes = {host_volume_path: {'bind': container_volume_path, 'mode': 'rw'}}
    command = f"python /server.py {folder}"
    container = client.containers.run("py_sandbox", command, auto_remove=True, volumes=volumes, detach=True, network="cauchey_internal_no_internet", mem_limit='1g', cap_drop=["ALL"])
    print(f"Started container {container.id}.")
    #result = container.wait()
    try:
        result = container.wait(timeout=5)
    except Exception as e:
        # This block will execute if the wait timeout is reached
        result = {"StatusCode": 1, "Error": "Превышено время выполнения программы"}
        print("Timeout reached. Stopping container...", flush=True)
        container.stop()
        container.remove()
        print("Container has been forcibly stopped.", flush=True)
    return result
