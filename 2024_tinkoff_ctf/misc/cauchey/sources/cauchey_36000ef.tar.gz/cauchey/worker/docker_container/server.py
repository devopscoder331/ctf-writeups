import subprocess
import os
import sys


folder = sys.argv[1]
folder = f"/tmp/{folder}"
input_path = os.path.join(folder, 'input.txt')
script_path = os.path.join(folder, 'code.py')
results_path = os.path.join(folder, 'results.txt')
tests = {}
with open(input_path, 'r') as file:
    lines = file.readlines()
print(lines, flush=True)
with open(results_path, 'w') as results_file:
    for line in lines:
        if line.strip():
            input1, input2 = line.strip().split()
            command = ['python', script_path, input1, input2]
            result = subprocess.run(command, text=True, capture_output=True)
            print(result.returncode, result.stdout, flush=True)
            if result.returncode == 0:
                output = f"{input1} {input2} {result.stdout}"
            else:
                output = f"{input1} {input2} {result.stderr}"
            results_file.write(output)
