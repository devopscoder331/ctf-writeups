from flask import Flask
from main.config import settings

app = Flask(__name__)

app.config["SECRET_KEY"] = settings.secret_key
app.config["DEBUG"] = settings.debug
app.config["SESSION_PERMANENT"] = settings.session_permanent
app.config["SESSION_TYPE"] = settings.session_type
app.config["SESSION_COOKIE_HTTPONLY"] = settings.session_cookie_httponly
app.config["THREADED"] = settings.threaded
app.config["REDIS_HOST"] = settings.redis_host
app.config["REDIS_PORT"] = settings.redis_port

from main import views
