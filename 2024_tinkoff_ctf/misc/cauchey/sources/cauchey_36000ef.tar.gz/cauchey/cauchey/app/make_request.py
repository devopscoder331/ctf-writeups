def queued_job(title, message, author, recipient, tokens):
    pass