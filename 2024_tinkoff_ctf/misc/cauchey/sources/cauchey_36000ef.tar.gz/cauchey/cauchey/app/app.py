from main import app
from main.config import settings

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=settings.web_port, threaded=settings.threaded, debug=settings.debug)
