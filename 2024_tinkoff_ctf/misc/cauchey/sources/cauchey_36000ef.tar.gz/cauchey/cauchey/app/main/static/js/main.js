$(document).ready(function() {
    if (window.location.pathname === '/') {
        var widgetId;
        captcha = document.getElementById('g-recaptcha')
        widgetId = grecaptcha.render(captcha, { 'sitekey': '6Ld0sCEUAAAAAKu8flcnUdVb67kCEI_HYKSwXGHN' });
        function fetchMessages() {
            $.ajax({
                url: '/tries',
                method: 'GET',
                success: function(data) {
                    const messagesList = $('#messages-list tbody');
                    messagesList.empty();  // Clear current content before adding new data
        
                    data.forEach(function(message) {
                        const messageStatus = message.completed === 'True' ? 'Завершено' : 'В процессе';
                        let winStatus;
                        if (message.win === 'True') {
                            winStatus = 'Победа';  // Win
                        } else if (message.win === 'False') {
                            winStatus = 'Поражение';  // Lose
                        } else {
                            winStatus = 'N/A';  // Not applicable or unknown
                        }

                        let displayTitle = message.title;
                        if (message.title && message.title.length === 30) {
                            displayTitle += '...';
                        }
        
                        const messageRow = $(`<tr data-id="${message.id}">
                        <td>${displayTitle}</td>
                        <td>${messageStatus}</td>
                        <td>${winStatus}</td>
                    </tr>`);
        
                        messagesList.append(messageRow);  // Append the row to the table
                    });
                },
                error: function(xhr) {
                    console.log('Error fetching messages:', xhr.responseText);
                }
            });
        }
        
        // Initial fetch of messages
        fetchMessages();
        // Optionally, set an interval for polling if messages need to be updated regularly
        setInterval(fetchMessages, 3000);  // Adjust interval as needed
        

        // Submitting the golf form
        $('#golf-form').on('submit', function(e) {
            e.preventDefault();
            const messageText = $('#message_text').val();
            var $send_button = $('#task_send');
            $send_button.prop('disabled', true).addClass('disabled');
            const recaptchaToken = document.getElementById('g-recaptcha-response').value;
            $.ajax({
                url: '/golf',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({"text": messageText, "g-recaptcha-response": recaptchaToken,}),
                success: function(response) {
                    $('#message_status').html('<strong></strong> ' + response.message);
                    $send_button.prop('disabled', false).removeClass('disabled');
                },
                error: function(xhr) {
                    $('#message_status').html('<strong>Ошибка:</strong> ' + xhr.responseJSON.error);
                    $send_button.prop('disabled', false).removeClass('disabled');
                }
            });
            grecaptcha.reset(widgetId);
        });

        $('#messages-list tbody').on('click', 'tr', function() {
            // Assuming each row has a data-id attribute with the message ID
            const messageId = $(this).data('id');
            loadMessageDetails(messageId);
        });
        var tokensValue = $('#tokens').text();  // Attempt to get the value from the element
        if (!tokensValue) {  // Check if the value is falsy (empty, undefined, etc.)
            tokensValue = 0;  // Set default value
        } else {
            tokensValue = parseInt(tokensValue);  // Ensure the value is an integer
            if (isNaN(tokensValue)) {  // Additional check if the conversion fails
                tokensValue = 0;  // Set default value if the existing value is not a number
            }
        }
        function loadMessageDetails(messageId) {
            $.ajax({
                url: '/tries/' + messageId,  // URL to fetch details for a specific message
                type: 'GET',
                success: function(response) {
                    // Format the response to handle new lines and long text
                    const formattedResponse = response.response ? response.response.replace(/\n/g, '<br>') : 'Ответ еще не поступил';
                    let gameResult;
                    if (response.result === "True") {
                        gameResult = 'Победа';
                        if (tokensValue < response.tokens){
                            gameResult = 'Победа, но потрачено слишком много токенов';
                        }
                    } else if (response.result === "False") {
                        gameResult = 'Поражение';
                    } else {
                        gameResult = 'Игра не началась';
                    }
                    
                    let state;
                    if (response.completed === "True") {
                        state = 'Выполнение завершено';
                    } else {
                        state = 'В процессе выполнения';
                    }

                    Swal.fire({
                        title: 'Детали задачи',
                        html: `<strong>Ваше описание задачи:</strong> ${response.message || 'Задача пустая.'}
                            <br><strong>Статус:</strong> ${state}
                            <br><strong>Код от модели:</strong> <div style="max-height:200px; overflow-y:auto; text-align: left; font-family: Consolas, monospace; white-space: pre-wrap;">${formattedResponse}</div>
                            <br><strong>Игровая информация:</strong> ${response.result_message || '-'} 
                            <br><strong>Результат игры:</strong> ${gameResult}
                            <br><strong>Затраченные токены:</strong> ${response.tokens}`,
                        icon: 'info',
                        showCloseButton: true,
                        showCancelButton: true,
                        confirmButtonText: 'Обновить',
                        cancelButtonText: 'Закрыть'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            loadMessageDetails(messageId);  // Reload the modal with refreshed data
                        }
                    });
                },
                error: function(xhr) {
                    Swal.fire({
                        title: 'Error',
                        text: 'Failed to fetch message details: ' + xhr.responseText,
                        icon: 'error',
                        confirmButtonText: 'Close'
                    });
                }
            });
        }
    }
    
    if (window.location.pathname === '/login') {
        $('#login-form').on('submit', function(e) {
        e.preventDefault();
        const username = $('#username').val();

        $.ajax({
            url: '/login',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({username: username}),
            dataType: 'json',
            success: function(response) {
                if (response.redirect) {
                    // Perform the redirect to the URL provided by the server
                    window.location.href = response.redirect;
                }
            },
            error: function(xhr) {
                // Handle error, perhaps display a message to the user
                alert('Вход не увенчался успехом: ' + xhr.responseJSON.error);
            }
            });
        });
    }
});

