from flask import Flask, request, jsonify
import openai
import redis
from rq import Queue
import time
import re
from functools import wraps
from flask import request, session, render_template, redirect, url_for
from main import app
import uuid
import tiktoken
from rq import Queue
import redis
from redis import Redis
from make_request import queued_job
from requests.adapters import HTTPAdapter, Retry
import requests
from main.config import settings
import json

tokens_threshold = 119

# Setup Redis connection and RQ queue
r = redis.Redis(host=settings.redis_host, port=settings.redis_port, db=0)
q = Queue(connection=Redis(host=settings.redis_host, port=settings.redis_port))


@app.after_request
def add_header(response):
    response.headers['Cache-Control'] = 'no-cache'
    return response

def session_check():
    if not session.get('username'):
        return False
    return True


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('username'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def check_string(s):
    pattern = r'^[a-zA-Zа-яА-Я0-9_\- ]+$'
    return bool(re.match(pattern, s))


def num_tokens_from_string(string: str, encoding_name: str) -> int:
    encoding = tiktoken.encoding_for_model(encoding_name)
    num_tokens = len(encoding.encode(string))
    return num_tokens


@app.route('/', methods=['GET', 'POST'])
@login_required
def index():
    return render_template('index.html', username=session.get('username'), tokens=tokens_threshold)


def username_exists(username):
    return r.sismember('usernames', username)

def add_username(username):
    added = r.sadd('usernames', username)
    if added == 1:
        return True
    else:
        return False


@app.route('/login', methods=['GET', 'POST'])
def login():
    if session.get('username'):
        return redirect(url_for('golf'))
    else:
        if request.method == 'POST':
            data = request.json
            username = data.get('username')
            if not username:
                return {"error": "Имя не может быть пустым"}, 400
            if not check_string(username):
                return {"error": "Недопустимые символы в имени"}, 400
            if not add_username(username):
                return {'error': 'Такое имя уже занято'}, 409
            session["username"] = username
            return jsonify({"redirect": url_for('index')}), 200
                
        else:
            return render_template('login.html')


def store_message(message_id, username, message, tokens):
    hash_key = f"user:{username}:message:{message_id}"
    r.hmset(hash_key, {'message': message, "tokens":tokens, 'completed': "False", "title": message[:30]})
    r.sadd(f"user:{username}:messages", message_id)
    store_message_sorted(username,hash_key)
    return message_id


def update_message(username, message_id, new_message=None, new_response=None):
    hash_key = f"user:{username}:message:{message_id}"
    if new_message:
        r.hset(hash_key, 'message', new_message)
    if new_response:
        r.hset(hash_key, 'response', new_response)


def store_message_sorted(username, hash_key):
    timestamp = int(time.time())
    r.zadd(f"user:{username}:timeline", {hash_key: timestamp})


def get_message_by_id(username, message_id):
    hash_key = f"user:{username}:message:{message_id}"
    message_data = r.hgetall(hash_key)
    if message_data:
        message_data_decoded = {k.decode('utf-8'): v.decode('utf-8') for k, v in message_data.items()}
        return message_data_decoded
    else:
        return None

def retrieve_specific_message_details(username, limit=100):
    # Get keys from the sorted set, latest first
    keys = r.zrevrange(f"user:{username}:timeline", 0, limit - 1)
    print(keys,flush=True)
    # Fetch specific details for each key
    messages = []
    for key in keys:
        title, completed, win = r.hmget(key, 'title', 'completed', 'win')
        if title and completed:
            title = title.decode('utf-8')
            completed = completed.decode('utf-8')
        else:
            title = "Title not found"
            completed = "Status unknown"
        if win:
            win = '-'

        messages.append({
            'id': key.decode('utf-8').split(':')[-1],
            'title': title,
            'completed': completed,
            'win': win
        })

    return messages



@app.route('/golf', methods=['POST'])
@login_required
def golf():
    data = request.json
    message = data.get('text')
    if len(message) > 1500:
        return {"error": "Сообщение слишком длинное"}, 400
    
    message_id = uuid.uuid4().hex
    tokens = num_tokens_from_string(message, "gpt-3.5-turbo-0125")
    print(store_message(message_id, session.get('username'), message, tokens),flush=True)
    q.enqueue(queued_job, message, session.get('username'), message_id, tokens)
    return {"message":f"Работа пошла!", "error":False}


@app.route('/scoreboard', methods=['GET'])
def scoreboard():
    scores = r.zrange("scoreboard", 0, -1, withscores=True)
    formatted_scores = {name.decode('utf-8'): score for name, score in scores}
    return render_template('scoreboard.html', scores=formatted_scores)


@app.route('/tries/<message_id>', methods=['GET'])
@login_required
def get_message(message_id):
    message = get_message_by_id(session.get('username'), message_id)
    if message:
        if message.get('result') == "True":
            if int(message.get('tokens')) < tokens_threshold:
                message['result_message'] = message.get('result_message') + ' — вот и ваш флаг: tctf{XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX}'
        return jsonify(message)
    else:
        return {"error": "Сообщение не найдено"}, 404


@app.route('/tries', methods=['GET'])
@login_required
def get_tries():
    username = session.get('username')
    messages = retrieve_specific_message_details(username)
    print(messages,flush=True)
    return jsonify(messages)


if __name__ == '__main__':
    app.run(debug=True)
